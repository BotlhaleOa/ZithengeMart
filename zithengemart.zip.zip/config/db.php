<?php
$host = "sql302.infinityfree.com";
$dbname = "if0_41982578_zithengemart";
$username = "if0_41982578";
$password = "BotlhaleNth04";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>