<?php
session_start();
if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit;
}
require_once '../config/db.php';

$total_users    = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'buyer' OR role = 'seller'")->fetchColumn();
$total_listings = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$pending        = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 'pending'")->fetchColumn();
$active         = $pdo->query("SELECT COUNT(*) FROM products WHERE status = 'active'")->fetchColumn();

// Recent listings
$recent = $pdo->query("SELECT p.*, u.full_name, c.category_name FROM products p JOIN users u ON p.seller_id = u.user_id JOIN categories c ON p.category_id = c.category_id ORDER BY p.created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - ZithengeMart Admin</title>
  <link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
<div class="admin-layout">

<!-- MOBILE TOPBAR -->
<div class="admin-topbar">
  <span class="admin-topbar-brand">ZITHENGEMART</span>
  <button class="admin-menu-btn" onclick="openAdminMenu()">
    <span></span><span></span><span></span>
  </button>
</div>

<!-- SIDEBAR OVERLAY -->
<div class="admin-sidebar-overlay" id="adminOverlay" onclick="closeAdminMenu()"></div>

<?php include 'includes/sidebar.php'; ?>

<script>
function openAdminMenu(){
  document.querySelector('.sidebar').classList.add('mobile-open');
  document.getElementById('adminOverlay').classList.add('active');
  document.body.style.overflow = 'hidden';
}
function closeAdminMenu(){
  document.querySelector('.sidebar').classList.remove('mobile-open');
  document.getElementById('adminOverlay').classList.remove('active');
  document.body.style.overflow = '';
}
</script>

<div class="main-content">
  <div class="page-header">
    <h2>Dashboard</h2>
	<p>Welcome back, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>
	  <span class="role-badge"><?php echo ucfirst($_SESSION['admin_role']); ?></span>
	  
	  <!-- Statistics -->
	  <div class="stat-grid">
	    <div class="stat-card">
	      <div class="stat-icon">👥</div>
	      <div class="stat-number"><?php echo $total_listings; ?></div>
	      <div class="stat-label">Total Users</div>
	  </div>
	  <div class="stat-card orange">
	    <div class="stat-icon">⏳</div>
	    <div class="stat-number"><?php echo $pending; ?></div>
	    <div class="stat-label">Active Listings</div>
	  </div>
  </div>
  
  <!-- Recent Listings -->
  <div class="content-card">
    <div class="card-header">
	  <h3>Recent Listings</h3>
	  <a href="listings.php" class="btn-sm"View All</a>
	</div>
	<table class="admin-table">
	  <thead>
	    <tr>
		  <th>Title</th>
		  <th>Seller</th>
		  <th>Category</th>
		  <th>Price</th>
		  <th>Status</th>
		  <th>Date</th>
		</tr>
      </thead>	
      <tbody>
        <?php foreach($recent as $r){ ?>
        <tr>
          <td><?php echo htmlspecialchars($r['title']); ?></td>	
		  <td><?php echo htmlspecialchars($r['full_name']); ?></td>	
		  <td><?php echo htmlspecialchars($r['category_name']); ?></td>	
		  <td>R<?php echo htmlspecialchars($r['price']); ?></td>	
		  <td><span class="status-badge status-<?php echo $r['status']; ?>"><?php echo ucfirst($r['status']); ?></span></td>
		  <td><?php echo date('d M Y', strtotime($r['created_at'])); ?></td>
		</tr> 
		<?php } ?>
	  </tbody>
	</table>
  </div>

  </div>
</div>
</body>
</html>
	  
	  
	  
	  